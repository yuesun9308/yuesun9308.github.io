function [ xhat, bx, bx_hat, bx_test, bx_test_hat, error_t,error_v] = sysid_from_data(data, N,T,reg,test_size,p,m,r)
t0 = 100;
u = data(N:(T+N),1:p);
bx = data(N:(T+N-1),(p+1):(p+m))';
  Uin = zeros(T,N*p);
  Uinrow = data(N:-1:1,1:p);
  for i = 1:T
      if(i>1)
        Uinrow(2:N,:) = Uinrow(1:(N-1),:);
        Uinrow(1,:) = u(i,:);
      end
      Uin(i,:) = reshape(Uinrow',1,p*N);
  end
if(reg==0)  
    xhat = Uin\bx';
%     cvx_begin quiet
%     cvx_precision(0.05)
%     cvx_solver sdpt3
%       variable xhat(N*p,m)
%       expression H((N+1)/2*p,(N+1)/2*m)
%       for i = 1:N
%           if(i<=(N+1)/2)
%               for j = 1:i
%                   H(((j-1)*p+1):(j*p) , ((i-j)*m+1):((i+1-j)*m)) = xhat(((i-1)*p+1):(i*p),:);
%               end
%           else
%               for j = (i+1-(N+1)/2):((N+1)/2)
%                   H(((j-1)*p+1):(j*p) , ((i-j)*m+1):((i+1-j)*m)) = xhat(((i-1)*p+1):(i*p),:);
%               end
%           end
%       end
%       minimize norm(Uin*xhat - bx','fro')+ 0.000005*norm(xhat,2)
%     cvx_end
% %     H = H';
% %     [V_1,S,V_2] = svd(H(:,1:(N-1)/2*p));
% %     S((r+1):(N+1)/2*m,(r+1):(N-1)/2*p) = 0;
% %     L = V_1*S*V_2';
% %     V_1 = V_1*sqrt(S);
% %     C = V_1(1:m,1:r);
% %     V_2 = sqrt(S)*V_2';
% %     B = V_2(1:r,1:p);
% %     A = pinv(V_1)*H(1:(N+1)/2*m,(p+1):(N+1)/2*p)*pinv(V_2);
% %     A = A(1:r,1:r);
% %     xhat = [];
% %     A0 = eye(size(A,1));
% %     for i = 1:N
% %         xhat = [xhat,C*A0*B];
% %         A0 = A0*A;
% %     end
% %     xhat = xhat';
else
%     xhat = zeros(N*p,m);
%     H = zeros((N+1)/2*p,(N+1)/2*m);
%   for t = 1 : t0
%       for i = 1:N
%           if(i<=(N+1)/2)
%               for j = 1:i
%                   H(((j-1)*p+1):(j*p) , ((i-j)*m+1):((i+1-j)*m)) = xhat(((i-1)*p+1):(i*p),:);
%               end
%           else
%               for j = (i+1-(N+1)/2):((N+1)/2)
%                   H(((j-1)*p+1):(j*p) , ((i-j)*m+1):((i+1-j)*m)) = xhat(((i-1)*p+1):(i*p),:);
%               end
%           end
%       end
%       [Uh,~,Vh] = svd(H); 
%       Hgrad = Uh * Vh';
%       gxhat = zeros(N*p,m);
%       gxhattest = zeros(N*p,m);
%       for i = 1:N
%           if(i<=(N+1)/2)
%               for j = 1:i
%                   gxhat(((i-1)*p+1):(i*p),:) = gxhat(((i-1)*p+1):(i*p),:) + H(((j-1)*p+1):(j*p) , ((i-j)*m+1):((i+1-j)*m));
%                   gxhattest(((i-1)*p+1):(i*p),:) = gxhattest(((i-1)*p+1):(i*p),:) + 1;
%               end
%           else
%               for j = (i+1-(N+1)/2):((N+1)/2)
%                   gxhat(((i-1)*p+1):(i*p),:) = gxhat(((i-1)*p+1):(i*p),:) + H(((j-1)*p+1):(j*p) , ((i-j)*m+1):((i+1-j)*m));
%                   gxhattest(((i-1)*p+1):(i*p),:) = gxhattest(((i-1)*p+1):(i*p),:) + 1;
%               end
%           end
%       end
%       disp(max(gxhattest));
%       disp(min(gxhattest))
%       grad = Uin' * (Uin*xhat - bx') + reg * gxhat;
%       if norm(grad)>1
%         grad = grad / norm(grad);
%       end
%       xhat = xhat - .5/sqrt(t) * grad;
%       if t<10
%         disp(norm(Uin*xhat - bx','fro')^2+ reg*norm_nuc(H))
%       end
%   end
    cvx_begin quiet
    cvx_precision(0.05)
    cvx_solver sdpt3
      variable xhat(N*p,m)
      expression H((N+1)/2*p,(N+1)/2*m)
      for i = 1:N
          if(i<=(N+1)/2)
              for j = 1:i
                  H(((j-1)*p+1):(j*p) , ((i-j)*m+1):((i+1-j)*m)) = xhat(((i-1)*p+1):(i*p),:);
              end
          else
              for j = (i+1-(N+1)/2):((N+1)/2)
                  H(((j-1)*p+1):(j*p) , ((i-j)*m+1):((i+1-j)*m)) = xhat(((i-1)*p+1):(i*p),:);
              end
          end
      end
      minimize sum_square(vec(Uin*xhat - bx'))+ reg*norm_nuc(H)
    cvx_end
end
pause = 0;
bx_hat = (Uin*xhat)';
Uin_test = zeros(T,N*p);
bx_test = data((T+N):(test_size + T+N-1),(p+1):(p+m))';
u = data((T+N):(test_size + T+N),1:p);
  Uinrow = data((T+N):-1:(T+1),1:p);
  for i = 1:test_size
      if(i>1)
        Uinrow(2:N,:) = Uinrow(1:(N-1),:);
        Uinrow(1,:) = u(i,:);
      end
      Uin_test(i,:) = reshape(Uinrow',1,p*N);
  end
bx_test_hat = (Uin_test*xhat)';
error_t = norm(bx_hat - bx,'fro')/norm(bx,'fro');
error_v = norm(bx_test_hat - bx_test,'fro')/norm(bx_test,'fro');



