% noise 
% fix a small T and change n
close all
hold off all
clear
set(gcf,'defaultAxesFontSize',30)

%% daisy
  r = 8; m = 1;
  %p = 2; 
  p = 1;
Udata = csvread('inv_pend_U_lin.csv'); 
Udata = Udata';
Ydata = csvread('inv_pend_y_lin.csv');
Ydata = Ydata(2:1001,1);
Y0 = Ydata;
noise = randn(1000,1);
Ydata = Y0 + .0 * noise / norm(noise) * norm(Y0);
y_nless = [Udata, Y0];
data = [Udata, Ydata];

%data = load('cd_player_arm.dat');
%data = data(:,1:3);

%% synthetic
load sys_id.mat
% u = randn(1000,1);
% % A = diag(randn(r,1));
% % A = A / max(max(A));
% A = zeros(r);
% A(1:(r-1), 2:r) = eye(r-1);
% B = zeros(r,1);
% B(r) = 1;
% % a_recur = 3 + randn(9);
% % a_recur = a_recur/max(abs(a_recur))/1.1;
% % 
% % poly_recur = conv([1,a_recur(1)],[1,a_recur(2)] );
% % for i=3:r
% %     poly_recur = conv(poly_recur,[1,a_recur(i)] );
% % end
% % A(r,:) = poly_recur((r+1):-1:2);
% A(r,:) = rand(r,1);
% A(r,:) = A(r,:) / sum(A(r,:)) / 1.5;
% A = A / max(eig(A)) / 1.1;
% 
% % 
% % data = [];
% % x0 = zeros(r,1);
% % for i=1:1000
% %     x0 = A * x0 + B * u(i); %+ randn(1)/20;
% %     data = [data; C*x0];
% % end
% % noise = randn(1000,1);
% % %data = data + norm(data,2)/norm(noise,2)/20 * noise;
% % awgn_p = 1;
% % data = awgn(data, 10 * awgn_p);
% % data = [data, u];
% 
% 
% 
% % ls test 
% r = 9; m = 1;
% p = 1;
% A = diag(randn(r,1));
% A = A/1.1/norm(A,2); % normalize A
% B = rand(r,p);
% B = B/norm(B); % normalize B
% C = rand(m,r);
% C = C/norm(C);
% D = randn(m,p);
% D = D/norm(D);
% x_true = [];
% A0 = eye(r);
% N = 2*r-1;
% T = 800;
% Z = [];
% data = [];
% 
% for i=(2*N+2):(T+2*N+1)
%     Z = [Z;y(i)];
%     data = [data;u(i:-1:i-2*n-1)];
% end

%%



%%
% T0 = 2000;
% load('imp_103.mat')
% limpu = size(imp_u,2);
% limpy = size(imp_y,2);
% u = randn(T0,1);
% data = zeros(T0,1);
% %data(1:limpy) = u(1:limpy);
% for i=(limpy+1):T0
%     data(i) = ( imp_u * u((i-limpu+1):i) - imp_y(1:(limpy-1)) * data((i-limpy+1):(i-1)) ) / imp_y(limpy);
% end
% data = [u,data];
% data = data(400:T0,:);
%% multi data
% N = 61;
% T = 20;
% T0 = 2000;
% u = randn(T0,N-2);
% K = diag(sqrt([1:(N-1)/2,(N-3)/2:-1:1]));
% u = u * K;
% mag_u0 = 10;
% delay = 1;
% u0 = mag_u0 * randn(T0,delay);
% data = zeros(T0, N-1);
% data(:,delay) = u0;
% for i=(delay+1):(N-1)
%     data(:,i) = data(:,i-delay)*pow_z + u(:,i-1);
% end
% data = data(:,N-1);
% data = [u,data];


%%
%reg = [0,0.01*2.^[0:9]]';
%reg = [0,1./[0.02,0.1,0.2,0.5:0.5:2,4,8,16]]';
%reg = [0,1./[0.1,0.5,2,4,8,16,24,30,40]]';
reg = [0];
rs = size(reg,1);
N = 91;
T = 40;

test_size = 800;
error_t_ave = zeros(rs,1);
error_v_ave = zeros(rs,1);

error_no_reg_t_ave = zeros((N-1)/2,1);
error_no_reg_v_ave = zeros((N-1)/2,1);
trial = 0;
load('heavy2.mat')

%s = size(T_list,1);
s = 1;
for trial= 1
    reg = [0];
    rs = size(reg,1);
    %% down sample system
    T0 = 2000;
    delay = 1;
    pow_z = (0.98)^delay;
    u = randn(T0,1);
    data = zeros(T0,1);
    data(1:delay) = u(1:delay);
    for i=delay+1:T0
        data(i) = data(i-delay)*pow_z + u(i);
    end
    data = [u,data];
    

    fignum = 4;
    Hhat_eig = zeros(min(p,m)*(N+1)/2,s,rs);
    h_all = [];
    str_all = [];
    bx_test = zeros(test_size,m,rs);
    bx = zeros(T,m,rs);
    bx_hat = zeros(T,m,rs);
    bx_test_hat = zeros(test_size,m,rs);

    bx_no_reg_test = zeros(test_size,m,(N-1)/2);
    bx_no_reg = zeros(T,m,(N-1)/2);
    bx_no_reg_hat = zeros(T,m,(N-1)/2);
    bx_no_reg_test_hat = zeros(test_size,m,(N-1)/2);
    Hhat_no_reg_eig = zeros(min(p,m)*(N+1)/2,s,(N-1)/2);
    error_t = zeros(rs,1);
    error_v = zeros(rs,1);

    error_no_reg_t = zeros((N-1)/2,1);
    error_no_reg_v = zeros((N-1)/2,1);


    for i = 1:rs
        [Hhat_eig(:,:,i),bx(:,:,i), bx_hat(:,:,i), bx_test(:,:,i), bx_test_hat(:,:,i),error_t(i), error_v(i)] =  sysid_time_sim_no_true(T,data,N,reg(i),test_size,p,m,(N-1)/2);
        %[Hhat_eig(:,:,i),bx(:,:,i), bx_hat(:,:,i), bx_test(:,:,i), bx_test_hat(:,:,i),error_t(i), error_v(i)] =  sysid_time_sim_no_true2(T,data,N,reg(i),test_size,p,m,(N-1)/2,y_nless);
    end
    close all
    hold off all
    set(gcf,'defaultAxesFontSize',30)
    %[zz1, zz2, zz3, zz4, bx_test_hat(:,1),zz5, zz6] =  sysid_time_sim_no_true(T,data,21,0,test_size,p,m,2);
    [err_min,err_argmin] = min(error_v(2:rs));
    err_argmin = err_argmin+1;
    figure(7)
    sHhat = size(Hhat_eig,1);
    semilogy(Hhat_eig(1:sHhat,1,1) / max(abs(Hhat_eig(1:sHhat,1,1))),'ok','MarkerSize',10,'LineWidth',2);
    ylabel('${\sigma_i(H)}$','Interpreter','Latex','FontName','Courier');
    xlabel('$i$','Interpreter','Latex')
    %name = sprintf('synthetic_ls_Hankel_eig_snr_%d', 10 * awgn_p);
    %saveas(gcf,name)
    %saveas(gcf,name,'epsc')
    figure(8)
    semilogy(Hhat_eig(1:sHhat,1,err_argmin) / max(abs(Hhat_eig(1:sHhat,1,err_argmin))),'ok','MarkerSize',10,'LineWidth',2);
    ylabel('${\sigma_i(H)}$','Interpreter','Latex','FontName','Courier');
    xlabel('$i$','Interpreter','Latex')
    %name = sprintf('synthetic_reg_Hankel_eig_snr_%d', 10 * awgn_p);
    %saveas(gcf,name)
    %saveas(gcf,name,'epsc')
    %legend(h_all,str_all(1,:),str_all(2,:),str_all(3,:))
    figure(18);
    for i=1:m
        figure(20+i)
        plot([bx(:,i,1); bx_test(:,i,1)],'k','linewidth',2);hold on;
        plot([bx_hat(:,i,1); bx_test_hat(:,i,1)],'b','linewidth',2);%hold on;
        %legend({'true data', 'estimation without regularizer','estimation with regularizer'},'fontsize', 30);
        legend({'true data', 'estimation without regularizer'},'fontsize', 30);
        %title('Training set size: 50, test set size: 400','fontsize', 30);
    end
    figure(80)
     plot([bx(:,i,1); bx_test(:,i,1)],'k','linewidth',2);hold on;
      plot([bx_hat(:,i,err_argmin); bx_test_hat(:,i,err_argmin)],'r','linewidth',2);
      legend({'true data', 'estimation with regularizer'},'fontsize', 30);
    %legend('true data', 'estimation without regularizer','estimation with regularizer');
    %title('Training set size: 50, test set size: 400','fontsize', 30);
    error_t_ave = (error_t_ave*(trial-1) + error_t) /trial;
    error_v_ave = (error_v_ave*(trial-1) + error_v) /trial;
    figure(20)
    plot(1./reg(2:rs),error_t(2:rs),'linewidth',2);
    hold on
    plot(1./reg(2:rs),error_v(2:rs),'linewidth',2);
    legend({'training error','validation error'},'fontsize', 30);
    figure(200)
    plot(1./reg(2:rs),error_t_ave(2:rs),'linewidth',2);
    hold on
    plot(1./reg(2:rs),error_v_ave(2:rs),'linewidth',2);
    legend({'average training error','average validation error'},'fontsize', 30);
    save('heavy2.mat')
    name = sprintf('heavy_reg');
    saveas(gcf,name)
    saveas(gcf,name,'epsc')


    figure(15)
    plot(1./reg(2:rs),error_t(2:rs),'linewidth',2);
    hold on
    plot(1./reg(2:rs),error_v(2:rs),'linewidth',2);
    legend({'training error','validation error'},'fontsize',30);
    xlabel('$1/\lambda$','Interpreter','Latex' ,'fontsize',30);
    %name = sprintf('synthetic_reg_Hankel_size_range_snr_%d', 10 * awgn_p);
    %saveas(gcf,name)
    %saveas(gcf,name,'epsc')

    %Hhat_eig = zeros(r+1,s,4);
    %N_list = [(2*r-9):4:(2*r)+3]';
    %sysid_time_sim_N(29,H_true,A,B,C,D,r,p,m,N_list,0,fignum);
    %fignum = fignum+1;


    %for i = 2:(N-1)/2
    for i = [(N-1)/2]
        [~,bx_no_reg(:,:,i), bx_no_reg_hat(:,:,i), bx_no_reg_test(:,:,i), bx_no_reg_test_hat(:,:,i),error_no_reg_t(i), error_no_reg_v(i)] =  sysid_time_sim_no_true(T,data,i*2-1,0,test_size,p,m,i);
    end
    [err_min,err_argmin] = min(error_no_reg_v(2:(N-1)/2));
    err_argmin = err_argmin+1;
    figure(30)
    plot([bx_no_reg(:,1,err_argmin); bx_no_reg_test(:,1,err_argmin)],'k','linewidth',2);hold on;
    plot([bx_no_reg_hat(:,1,err_argmin); bx_no_reg_test_hat(:,1,err_argmin)],'r','linewidth',2);
    legend({'true data', 'estimation without regularizer'},'fontsize', 30);
    figure(41)
    plot(2:(N-1)/2,error_no_reg_t(2:(N-1)/2),'linewidth',2);
    hold on
    plot(2:(N-1)/2,error_no_reg_v(2:(N-1)/2),'linewidth',2);
    legend({'training error','validation error'},'fontsize', 30);
    xlabel('Hankel size','fontsize', 30);
    
    error_no_reg_t_ave = (error_no_reg_t_ave*(trial-1) + error_no_reg_t) /trial;
    error_no_reg_v_ave = (error_no_reg_v_ave*(trial-1) + error_no_reg_v) /trial;
    figure(450)
    plot(2:(N-1)/2,error_no_reg_t_ave(2:(N-1)/2),'linewidth',2);
    hold on
    plot(2:(N-1)/2,error_no_reg_v_ave(2:(N-1)/2),'linewidth',2);
    legend({'average training error','average validation error'},'fontsize', 30);
    save('heavy2.mat')
    name = sprintf('heavy_ls');
    saveas(gcf,name)
    saveas(gcf,name,'epsc')


%     T = 10:20:200;
%     T_size = size(T,2);
%     error_T_t = zeros(T_size,1);
%     error_T_v = zeros(T_size,1);
%     for i = [1:T_size]
%         [~,~,~,~,~,error_T_t(i), error_T_v(i)] =  sysid_time_sim_no_true(T(i),data,i*2-1,0,test_size,p,m,i);
%     end
%     [err_min,err_argmin] = min(error_no_reg_v);
%     figure(51)
%     plot(T,error_T_t,'LineWidth',2);
%     hold on
%     plot(T,error_T_v,'LineWidth',2);
%     legend({'training error','validation error'},'fontsize', 30);
%     xlabel('T','fontsize', 30);
end



