function [ Hhat_eig,bx, bx_hat, bx_test, bx_test_hat,error_t,error_v ] = sysid_time_sim_no_true2( T_list,data,N,reg,test_size,p,m,r,y_nless )

err = [];
err_eig = [];
Hhat_eig = [];
s = size(T_list,1);
for i = 1:s
    T = T_list(i);
    [xhat,bx, bx_hat, bx_test, bx_test_hat,error_t,error_v] = sysid_from_data2(data,N,T,reg,test_size,p,m,r,y_nless);
    bx = bx';
    bx_hat = bx_hat';
    bx_test = bx_test';
    bx_test_hat = bx_test_hat';
    x_size = size(xhat);
    x_size = x_size(1)/p;
    xhat2 = [];
    Hhat = [];
    for stack = 1:m
        xhat2 = [];
        for j = 1:x_size
            xhat2 = [xhat2, xhat( ((j-1)*p+1):(j*p),stack )];
        end
        Hhat = [Hhat, Hrx(xhat2,(N-1)/2)];
    end
    %err = [err;norm(Hhat - H_true, 'fro')];
    Hhat_eig = [Hhat_eig,svd(Hhat)];
    %H_true_sort = sort(abs(eig(H_true)),'descend');
    Hhat_sort = sort(svd(Hhat),'descend');
    H_size = size(Hhat_sort,1);
    %err_eig = [err_eig, norm(Hhat_sort(1:H_size) - H_true_sort(1:H_size))];
end
%h = plot(T_list,err_eig,'linewidth',2);
%xlabel('number of samples','fontsize',14);
%ylabel('error of eigenvalues', 'fontsize',14);
end

