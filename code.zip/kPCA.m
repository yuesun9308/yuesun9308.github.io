H = diag([4,3,2,1,0]);
X = [zeros(1,3);eye(3);zeros(1,3)];
% optimal X = [eye(3);zeros(2,3)]
T = 1000;
eta = 0.1;
r = 1e-2;
l = zeros(T,1);
tth = 10;
t0 = -10;
t = 1;
while(t<T)
    V = (eye(5) - X*X') * H * X;
    if (t-t0<10||norm(V)>0.1)
        V = eta * V;
    else
        if ((t-t0==10)&&(real(trace(X' * H * X)/2) - l(t0) > -r))
            break
        else
            V = r * randn(5,3);
            t0 = t;
        end
    end
    P = (X+V)'*(X+V);
    [U,S,W] = eig(P);
    P = U*diag(1./sqrt(diag(S)))*W';
    X = (X+V) * P;
    l(t) = real(trace(X' * H * X)/2);
    t = t+1;
end
plot(l(1:t-1),'k','linewidth',3)
xlabel('Iterations', 'fontsize',15)
ylabel('function value', 'fontsize',15)
