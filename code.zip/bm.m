clear
n = 100;
k = 20;
H = diag([4,3,2,1,0,zeros(1,n-5)]);
H(1:(n/k),1:(n/k)) = randn(n/k,n/k);
X = zeros(n,k);
for i=1:k
    X( ((i-1)*(n/k)+1):(i*(n/k)), i) = ones(n/k,1);
end
T = 1000;
eta = 0.2;
r = 1e-1;
l = zeros(T,1);
tth = 10;
t0 = -10;
t = 1;
while(t<T)
    V = H * X;
    for i=1:k
        V(i,:) = V(i,:) - (V(i,:)*X(i,:)')*X(i,:);
    end
    if (t-t0<tth||norm(V)>0.1)
        V = eta * V;
    else
        if ((t-t0==tth)&&(real(trace(X' * H * X)/2) - l(t0) > -r))
            break
        else
            V = randn(n,k);
            V = r*V/norm(V,'fro');
            t0 = t;
        end
    end
    X = X+V;
    for i=1:k
        X(i,:) = X(i,:)/norm(X(i,:),2);
    end
    %P = (X+V)'*(X+V);
    %[U,S,W] = eig(P);
    %P = U*diag(1./sqrt(diag(S)))*W';
    %X = (X+V) * P;
    l(t) = real(trace(X' * H * X)/2);
    t = t+1;
end
plot(l(1:t-1),'k','linewidth',3)
xlabel('Iterations', 'fontsize',15)
ylabel('Function value', 'fontsize',15)
axis([0,t+1,min(l),max(l)])
