clear
[x, y, z] = meshgrid(-1:0.02:1);               
f = x.^2 + 4 * y.^2 - z.^2;                   
[u v] = meshgrid((-1:0.02:1) * pi, (-1:0.02:1) * pi);  
xi = cos(u).*cos(v); yi = cos(u).*sin(v); zi = sin(u); 
cs = contourslice(x, y, z, f, xi, yi, zi, 20);       
set(cs, 'LineWidth', 5);
axis equal tight; grid on; box on;
g = x.^2 + y.^2 + z.^2;
hold all;
p = isosurface(x, y, z, g, 1); 
patch(p, 'EdgeColor', 'w', 'FaceColor', 'y', 'FaceAlpha', 0.3);

H = diag([1;-1;4]);
X = [1;0;0];
X0 = [X];
T = 1000;
eta = 0.1;
r = .2;
l = zeros(T,1);
tth = 10;
t0 = -10;
t = 1;
while(t<T)
    V = (eye(3) - X*X') * H * X;
    if (t-t0<10||norm(V)>0.01)
        V = eta * V;
    else
        if ((t-t0==10)&&(real(trace(X' * H * X)/2) - l(t0) > -r))
            break
        else
            V = r * randn(3,1);
            V = (eye(3) - X*X') * V;
            t0 = t;
        end
        r = 0;
    end
    
    %projection
    %P = (X-V)'*(X-V);
    %[U,S,W] = eig(P);
    %P = U*diag(1./sqrt(diag(S)))*W';
    %X = (X-V) * P;
    
    %exp map
    nV = norm(V,2);
    X = cos(nV) * X + sin(nV) * V / nV;
    
    X0 = [X0 X];
    t = t+1;
end
hold all;
plot3(X0(1,1:2), X0(2,1:2), X0(3,1:2),'k', 'Linewidth',5)
plot3(X0(1,2:size(X0,2)), X0(2,2:size(X0,2)), X0(3,2:size(X0,2)),'r', 'Linewidth',5)
xlabel('x[1]', 'fontsize', 14)
ylabel('x[2]', 'fontsize', 14)
zlabel('x[3]', 'fontsize', 14)

